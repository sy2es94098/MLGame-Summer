# Easy Game

## Game interface

## Game Config

## Game Blockly

## Flowchart

## Create a new game