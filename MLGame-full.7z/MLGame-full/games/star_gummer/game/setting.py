'''color'''
RED = "#ff0000"
GREEN = "#00ff00"
YELLOW = "#ffff00"

'''size'''
HEIGHT = 600
WIDTH = 600
BOSS_SIZE = (200, 100)
PLAYER_SIZE = (40, 40)
BULLET_SIZE = (10, 20)
PROP_SIZE = (20, 20)

'''command'''
LEFT_cmd = "LEFT"
RIGHT_cmd = "RIGHT"
SPEED_cmd = "SPEED"
BRAKE_cmd = "BRAKE"
